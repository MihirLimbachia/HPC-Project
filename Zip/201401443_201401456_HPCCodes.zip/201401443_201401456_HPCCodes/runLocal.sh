gcc -fopenmp ch_final.c -o r
./r 1000 4
./r 10000 4
./r 100000 4
./r 1000000 4
./r 10000000 4
